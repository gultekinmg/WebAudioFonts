console.log('load _tone_1211_GeneralUserGS_sf2_file');
var _tone_1211_GeneralUserGS_sf2_file={
	zones:[
		{
			midi:121
			,originalPitch:6000
			,keyRangeLow:0
			,keyRangeHigh:127
			,loopStart:-1
			,loopEnd:-2
			,coarseTune:11
			,fineTune:0
			,sampleRate:44100
			,ahdsr:false
			,file:'SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU3LjcyLjEwMQAAAAAAAAAAAAAA//tAwAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAACAAAFMgDr6+vr6+vr6+vr6+vr6+vr6+vr6+vr6+vr6+vr6+vr6+vr6+vr6+vr6+vr6+vr6+vr//////////////////////////////////////////////////////////////////8AAAAATGF2YzU3Ljk2AAAAAAAAAAAAAAAAJAWuAAAAAAAABTKfypZoAAAAAAD/++DEAAAIUANntAAAJ//ILj898jDWRKIwgAAiiiA4J3g+B8HAwUtBAMQfeIHLB8EAQBAEATB8Hwfg+fLny5/+UBAEHZcHz//++D59n+Awffg+8oGP/8H0tid4dndgRgCNdW7i8FQ6AIAcPAICMAowDQBzFBGOMTgudWwwEABDAEALGACTLKBoM5ZUMwEgBwKAGYDABafhhJGlGPeT6YAeAFmAWAGSDQ0ABmFKiBBg0YQi9q8EuC6rcljGChBCxhUgXKYWaGqMQau2s63V/o7IDKPlcsyNA+jMxQAUTKYTYxsQiABB4AEYsoGsVW5kcPRUw8EaGMS5AoTDog+0wwoTXMJYB4jABwAgDAE6t6Wg8AJLjpq194n9jxgOoIaYDeA7GBAAUJghoTcYFqC0GCegEjrt2irgryX5YZuzqAYhel0RMCoBDTAagMkwIIACMBTARDAOwGwwCkAXMAGAJKSOv1KY+/lu3/1rdbszKrcwBAAdAoQADoAACR0AAAABeKAAYGAITAGwEqvn9JdtTlaxyRUtavm/sklNLepeGADgEgsAXmARAHZgCABqRAJBgEoB0YBKAkGAIgBZCAaIzBwAVasQ1lyPSGxrHeOGGs+0uGu0tW93LeHOmAFAFYAAExIAEMAFABjABwBgKgAIgABAQABocgsAPpGpmmAAgCgBADkAeHO/vv59/effz/8+8/8P/DXP///////9f/////////q0gQAHKoAAMADL0pWgUAUQnLjLql9VEDAAQBAwAMAUL/koAchk5ajScz/tEXNE0tnqQ2AgAupMQU1FMy45OS41qqqqqqqqTEFNRTMuOTkuNaqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xDE1gPAAAH+HAAAIAAANIAAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqg=='
			,anchor:0.00551020
			//_tone.Gtr_Click
		}
	]
};
