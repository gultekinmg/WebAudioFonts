console.log('load _tone_0983_GeneralUserGS_sf2_file');
var _tone_0983_GeneralUserGS_sf2_file={
	zones:[
		{
			midi:98
			,originalPitch:8700
			,keyRangeLow:0
			,keyRangeHigh:109
			,loopStart:9
			,loopEnd:114
			,coarseTune:0
			,fineTune:-18
			,sampleRate:44100
			,ahdsr:true
			,file:'SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU3LjcyLjEwMQAAAAAAAAAAAAAA//tAwAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAACAAADqgDc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc//////////////////////////////////////////////////////////////////8AAAAATGF2YzU3Ljk2AAAAAAAAAAAAAAAAJAZKAAAAAAAAA6rmAl/YAAAAAAD/+7DEAAAG9Cl5oIxBoaMU7rzxihyJtMAIAuAO3wIicRD676AAALeHymJw/D/ggXP8pLn2fKBkoGPwz+XPl3w/KOP5fPxB/dy75Op0h+V80RCQBFgKSjmAWlWFSISOEN0KCI6CmA/J/DEcxpKpcp5XRvAICb1VSjM2zakzeUpfrQ3RkM8vm6GcKBAR4NeWWDX6gacFQ0IhMPOg1ErlnWESow8HSRZbjpEqpR5oiUs7JSz5CVdDqgi6+PkAIyulSERCEsVOFyhcZGg+cLkCNAc7f7sYpgYIGDBA0DBy7FVVVNv/6aaaakxBTUUzLjk5LjWqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7IMTeA8XoYwcgJEPIAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqo='
			,anchor:0.00215419
			//_tone.JazzGuitLoop
		}
	]
};
