console.log('load _tone_1271_Aspirin_sf2_file');
var _tone_1271_Aspirin_sf2_file={
	zones:[
		{
			midi:127
			,originalPitch:12700
			,keyRangeLow:0
			,keyRangeHigh:127
			,loopStart:19
			,loopEnd:720
			,coarseTune:0
			,fineTune:0
			,sampleRate:44100
			,ahdsr:false
			,file:'SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU3LjcyLjEwMQAAAAAAAAAAAAAA//tAwAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAACAAAGAwCpqampqampqampqampqampqampqampqampqampqampqampqampqampqampqampqamp//////////////////////////////////////////////////////////////////8AAAAATGF2YzU3Ljk2AAAAAAAAAAAAAAAAJAPoAAAAAAAABgPxGPldAAAAAAD/+9DEAAAHcAF19AAABJnIL/8zgEiXdjNEMTnbrZCUCBxRcHwfB8HwwsTh9bygISn+CAYyhzghLg+fggCDv/iAMfB8/lDn/4Pvy4Pg+H//4n7OpUqXUylmmU2fTyTAYDAKowhLKwjXKMgUXoVUAzaex3pIBUul3F7DclIBnjDJbzNWVNJeVd6AZYaB1MW/aas1Figb2BXfyROEYwAYalAbg0LKr92VyuC2zNMf12H6qPi/6wiMlmMv+7j7x2W2YNopVvKBILtQFIORSfevcvppTlS/SU1yRzXKOcfag/P8KSr3Kg3OcllW7dt0Fe5nflMtxtTmst3t3c+4Tl7PONQ3SRmU1ofv9yyrUr/XLlLL35v1sqa529at5XZvKX0ln4Dn45SQ9XjMORmazjVFGdy2/Lp2mmYvEJndNLrdFhrH/z73/////////////pM7mrmfKfPDlbDvMccd67vvMdWs6KduzmpZjP2d8lc/es753WXLd7ePc7S2aHZnY3VnZnaa1utQiAMBE8LARGaUj6YY5jEpjwKALGQATYO6FOOr82Pwyh0JABTxiHHN2WLiWWlVWcG9Jk+bxSh2WxGAHKGDHJvFoZNKIBjqrY3JVPP250UXkdlnOZq1URnHUXuaa7q0RfWctUtLGHBYiYkIwBgiAjmbSzIYu5nxnnluZVblbOduxnkZjRgZhehcEowswxDBDB7MLsQQwVBk//Lf6prtyOUluaMbIU0wcBVTHcEpMYU0IxCR7DGJBAMMQO/e+a1/1srX4V9XZcYEAHYXBQMFECowNgOTBlDUMLMEYwVw2jDxAiMVQk3/////3X1UznMrnatbMwMgtTESD9MFIHQwUglTAqB6MMcNAwCQRDBtBoMEMBwwIwejClBG3//////9/v2eWpTzG13Uq+yYWgtJgiBZmGgD6YIIZhgIgNGAAAiYIIVRgEgjGDeB0YLQbJgLAnmC8CGAgGDAIAbEYKn//////////3LWW//+Y6y/+6/nP/9d//8wow0jBhDUMMUBwwxBSzBSC9ML4F0wLwjDAMAJMC0GIwTQEDAFAoKwKTBICFJAFTBMBXMBgBwGAFhwBBgPgcFoTAZBCMD8CYwCQLjA//ugxOYAO1IJe/nvDUAAADSDgAAErACMAYCUCgGCEBEwNAS6TEFNRTMuOTkuNaqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq'
			,anchor:0.01532880
			//_tone.MachGun1oct
		}
	]
};
